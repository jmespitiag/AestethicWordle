#ifndef INTERFACE_H
#define INTERFACE_H
#include "Game.h"
#include <stdio.h>
#include <random>
#include <string>

int selectDifficulty(){
  cout << "-*-*-*-*-*-*-* Please select the difficulty -*-*-*-*-*-*-"<<endl;
  cout << endl;
  cout << "¬ Enter '1' to play on 🃢Easy🃢 (3-5 words)" <<endl;
  cout << "¬ Enter '2' to play on 🃤Medium🃤 (6-8 words)" <<endl;
  cout << "¬ Enter '3' to play on 🃥Hard🃥 (9-11 words)" <<endl;
  cout << "¬ Enter '4' to play on 🃵GodMode🃵 (12+ words)" <<endl;
  cout << "¬ Enter any other character to exit"<<endl;
  cout << endl;
  
  string x;
  cin >> x;

  if(x == "1"){
    cout<< "*___EASY MODE SELECTED___*"<<endl;
    return stoi(x);
  }
    
  else if(x == "2"){
    cout<< "**__MEDIUM MODE SELECTED__**"<<endl;
    return stoi(x);
  }

  else if(x == "3"){
    cout<< "***_HARD MODE SELECTED_***"<<endl;
    return stoi(x);
  }

  else if(x == "4"){
    cout<< "****GOD MODE SELECTED... gook luck****"<<endl;
    return stoi(x);
  }
  
  else{
    return 0;
  }

  
    

}

int random(int low, int high)
{
  random_device rd;
  mt19937 gen(rd());
	uniform_int_distribution<> dist(low, high);
	return dist(gen);
}
void quit(){
  cout << "The excecution has overed... come back soon"<<endl;
}


string generateWord(int a){
  int b = random(1,29);
  switch(a){
    case 1:
      return easyWords[b];
      break;
    case 2:
      return mediumWords[b];
      break;
    case 3:
      return hardWords[b];
      break;
    case 4: 
      return godWords[b];
      break;
    case 0:
      return "";
      quit();
      break;
      
  }
}












#endif      