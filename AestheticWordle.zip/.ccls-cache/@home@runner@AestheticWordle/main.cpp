 #include "mainaux.h"
int main()
{
    start();

  
}
